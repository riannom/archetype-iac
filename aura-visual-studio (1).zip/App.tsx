
import React, { useState, useCallback, useEffect, createContext, useContext } from 'react';
import Sidebar from './components/Sidebar';
import Canvas from './components/Canvas';
import TopBar from './components/TopBar';
import PropertiesPanel from './components/PropertiesPanel';
import ConsoleManager from './components/ConsoleManager';
import DeviceManager from './components/DeviceManager';
import RuntimeControl, { RuntimeStatus } from './components/RuntimeControl';
import StatusBar from './components/StatusBar';
import Auth from './components/Auth';
import Dashboard from './components/Dashboard';
import { Node, Link, DeviceModel, Topology, ConsoleWindow, Annotation, AnnotationType } from './types';
import { generateNetlabYaml } from './services/netlabService';

type Theme = 'light' | 'dark';

interface ThemeContextType {
  theme: Theme;
  toggleTheme: () => void;
}

const ThemeContext = createContext<ThemeContextType | undefined>(undefined);

export const useTheme = () => {
  const context = useContext(ThemeContext);
  if (!context) throw new Error('useTheme must be used within a ThemeProvider');
  return context;
};

const App: React.FC = () => {
  const [theme, setTheme] = useState<Theme>(() => (localStorage.getItem('aura_theme') as Theme) || 'dark');
  const [currentUser, setCurrentUser] = useState<string | null>(null);
  const [activeTopology, setActiveTopology] = useState<Topology | null>(null);
  const [topologies, setTopologies] = useState<Topology[]>([]);
  
  const [view, setView] = useState<'designer' | 'images' | 'runtime'>('designer');
  const [nodes, setNodes] = useState<Node[]>([]);
  const [links, setLinks] = useState<Link[]>([]);
  const [annotations, setAnnotations] = useState<Annotation[]>([]);
  const [runtimeStates, setRuntimeStates] = useState<Record<string, RuntimeStatus>>({});
  const [consoleWindows, setConsoleWindows] = useState<ConsoleWindow[]>([]);
  const [selectedId, setSelectedId] = useState<string | null>(null);
  const [showYamlModal, setShowYamlModal] = useState(false);
  const [yamlContent, setYamlContent] = useState('');

  useEffect(() => {
    const root = window.document.documentElement;
    if (theme === 'dark') {
      root.classList.add('dark');
    } else {
      root.classList.remove('dark');
    }
    localStorage.setItem('aura_theme', theme);
  }, [theme]);

  const toggleTheme = () => setTheme(prev => prev === 'dark' ? 'light' : 'dark');

  // Load topologies
  useEffect(() => {
    const saved = localStorage.getItem('aura_topologies');
    if (saved) {
      try {
        setTopologies(JSON.parse(saved));
      } catch (e) {
        console.error("Failed to parse saved topologies");
      }
    }
    const user = localStorage.getItem('aura_user');
    if (user) setCurrentUser(user);
  }, []);

  // Save topologies
  useEffect(() => {
    if (topologies.length > 0) {
      localStorage.setItem('aura_topologies', JSON.stringify(topologies));
    }
  }, [topologies]);

  const handleLogin = (username: string) => {
    setCurrentUser(username);
    localStorage.setItem('aura_user', username);
  };

  const handleLogout = () => {
    setCurrentUser(null);
    setActiveTopology(null);
    localStorage.removeItem('aura_user');
  };

  const handleCreateTopology = () => {
    const name = `Project_${topologies.length + 1}`;
    const newTopo: Topology = { name, nodes: [], links: [], annotations: [] };
    setTopologies([...topologies, newTopo]);
    handleSelectTopology(newTopo);
  };

  const handleSelectTopology = (topo: Topology) => {
    setActiveTopology(topo);
    setNodes(topo.nodes);
    setLinks(topo.links);
    setAnnotations(topo.annotations || []);
    const initialStates: Record<string, RuntimeStatus> = {};
    topo.nodes.forEach(n => { initialStates[n.id] = 'stopped'; });
    setRuntimeStates(initialStates);
    setView('designer');
  };

  const handleDeleteTopology = (name: string) => {
    setTopologies(prev => prev.filter(t => t.name !== name));
  };

  const saveCurrentProgress = useCallback(() => {
    if (!activeTopology) return;
    const updatedTopo = { ...activeTopology, nodes, links, annotations };
    setTopologies(prev => prev.map(t => t.name === updatedTopo.name ? updatedTopo : t));
  }, [activeTopology, nodes, links, annotations]);

  useEffect(() => {
    saveCurrentProgress();
  }, [nodes, links, annotations, saveCurrentProgress]);

  const handleAddDevice = (model: DeviceModel) => {
    const id = Math.random().toString(36).substr(2, 9);
    const newNode: Node = {
      id,
      name: `${model.id.toUpperCase()}-${nodes.length + 1}`,
      type: model.type,
      model: model.id,
      version: model.versions[0],
      x: 300 + Math.random() * 50,
      y: 200 + Math.random() * 50,
      cpu: 1,
      memory: 1024
    };
    setNodes([...nodes, newNode]);
    setRuntimeStates(prev => ({ ...prev, [id]: 'stopped' }));
    setSelectedId(id);
  };

  const handleAddAnnotation = (type: AnnotationType) => {
    const id = Math.random().toString(36).substr(2, 9);
    const newAnn: Annotation = {
      id,
      type,
      x: 400,
      y: 300,
      text: type === 'text' ? 'New Label' : (type === 'caption' ? 'Note here' : ''),
      color: theme === 'dark' ? '#3b82f6' : '#2563eb',
      width: (type === 'rect' || type === 'circle') ? 100 : undefined,
      height: type === 'rect' ? 60 : undefined,
      targetX: type === 'arrow' ? 500 : undefined,
      targetY: type === 'arrow' ? 400 : undefined,
    };
    setAnnotations([...annotations, newAnn]);
    setSelectedId(id);
  };

  const handleUpdateStatus = (nodeId: string, status: RuntimeStatus) => {
    setRuntimeStates(prev => ({ ...prev, [nodeId]: status }));
    if (status === 'booting') {
      setTimeout(() => setRuntimeStates(prev => ({ ...prev, [nodeId]: 'running' })), 2000);
    }
  };

  const handleOpenConsole = (nodeId: string) => {
    setConsoleWindows(prev => {
      const existingWin = prev.find(w => w.deviceIds.includes(nodeId));
      if (existingWin) return prev.map(w => w.id === existingWin.id ? { ...w, activeDeviceId: nodeId } : w);
      
      const newWin: ConsoleWindow = {
        id: Math.random().toString(36).substr(2, 9),
        deviceIds: [nodeId],
        activeDeviceId: nodeId,
        x: 100, y: 100, isExpanded: true
      };
      return [...prev, newWin];
    });
  };

  const handleNodeMove = useCallback((id: string, x: number, y: number) => {
    setNodes(prev => prev.map(n => n.id === id ? { ...n, x, y } : n));
  }, []);

  const handleAnnotationMove = useCallback((id: string, x: number, y: number) => {
    setAnnotations(prev => prev.map(a => a.id === id ? { ...a, x, y } : a));
  }, []);

  const handleConnect = (sourceId: string, targetId: string) => {
    const exists = links.find(l => (l.source === sourceId && l.target === targetId) || (l.source === targetId && l.target === sourceId));
    if (exists) return;

    const newLink: Link = {
      id: Math.random().toString(36).substr(2, 9),
      source: sourceId,
      target: targetId,
      type: 'p2p'
    };
    setLinks([...links, newLink]);
    setSelectedId(newLink.id);
  };

  const handleUpdateNode = (id: string, updates: Partial<Node>) => {
    setNodes(prev => prev.map(n => n.id === id ? { ...n, ...updates } : n));
  };

  const handleUpdateLink = (id: string, updates: Partial<Link>) => {
    setLinks(prev => prev.map(l => l.id === id ? { ...l, ...updates } : l));
  };

  const handleUpdateAnnotation = (id: string, updates: Partial<Annotation>) => {
    setAnnotations(prev => prev.map(a => a.id === id ? { ...a, ...updates } : a));
  };

  const handleDelete = (id: string) => {
    setNodes(prev => prev.filter(n => n.id !== id));
    setLinks(prev => prev.filter(l => l.id !== id && l.source !== id && l.target !== id));
    setAnnotations(prev => prev.filter(a => a.id !== id));
    setSelectedId(null);
  };

  const handleExport = () => {
    if (!activeTopology) return;
    const yaml = generateNetlabYaml({ name: activeTopology.name, nodes, links });
    setYamlContent(yaml);
    setShowYamlModal(true);
  };

  const selectedItem = nodes.find(n => n.id === selectedId) || 
                       links.find(l => l.id === selectedId) || 
                       annotations.find(a => a.id === selectedId) || null;

  if (!currentUser) return <Auth onLogin={handleLogin} />;
  if (!activeTopology) return <Dashboard topologies={topologies} onSelect={handleSelectTopology} onCreate={handleCreateTopology} onDelete={handleDeleteTopology} onLogout={handleLogout} username={currentUser} />;

  const renderView = () => {
    switch(view) {
      case 'images': return <DeviceManager />;
      case 'runtime': return <RuntimeControl nodes={nodes} runtimeStates={runtimeStates} onUpdateStatus={handleUpdateStatus} />;
      default: return (
        <>
          <Sidebar onAddDevice={handleAddDevice} onAddAnnotation={handleAddAnnotation} />
          <Canvas 
            nodes={nodes} 
            links={links} 
            annotations={annotations}
            runtimeStates={runtimeStates}
            onNodeMove={handleNodeMove}
            onAnnotationMove={handleAnnotationMove}
            onConnect={handleConnect}
            selectedId={selectedId}
            onSelect={setSelectedId}
            onOpenConsole={handleOpenConsole}
            onUpdateStatus={handleUpdateStatus}
            onDelete={handleDelete}
          />
          <PropertiesPanel 
            selectedItem={selectedItem}
            onUpdateNode={handleUpdateNode}
            onUpdateLink={handleUpdateLink}
            onUpdateAnnotation={handleUpdateAnnotation}
            onDelete={handleDelete}
            nodes={nodes}
            links={links}
            onOpenConsole={handleOpenConsole}
            runtimeStates={runtimeStates}
            onUpdateStatus={handleUpdateStatus}
          />
        </>
      );
    }
  };

  const backgroundGradient = theme === 'dark' 
    ? 'bg-gradient-to-br from-slate-950 via-slate-900 to-slate-950 bg-gradient-animate'
    : 'bg-gradient-to-br from-slate-50 via-white to-slate-100 bg-gradient-animate';

  return (
    <ThemeContext.Provider value={{ theme, toggleTheme }}>
      <div className={`flex flex-col h-screen overflow-hidden select-none transition-colors duration-500 ${backgroundGradient}`}>
        <TopBar 
          labName={activeTopology.name} 
          onExport={handleExport}
          onDeploy={() => { alert('Deploying...'); }}
          onExit={() => { saveCurrentProgress(); setActiveTopology(null); }}
        />
        <div className="h-10 bg-white/60 dark:bg-slate-900/60 backdrop-blur-md border-b border-slate-200 dark:border-slate-800 flex px-6 items-center gap-1 shrink-0">
          <button onClick={() => setView('designer')} className={`h-full px-4 text-[10px] font-black uppercase border-b-2 transition-all ${view === 'designer' ? 'text-blue-600 dark:text-blue-500 border-blue-600 dark:border-blue-500' : 'text-slate-400 dark:text-slate-500 border-transparent'}`}>Designer</button>
          <button onClick={() => setView('runtime')} className={`h-full px-4 text-[10px] font-black uppercase border-b-2 transition-all ${view === 'runtime' ? 'text-blue-600 dark:text-blue-500 border-blue-600 dark:border-blue-500' : 'text-slate-400 dark:text-slate-500 border-transparent'}`}>Runtime</button>
          <button onClick={() => setView('images')} className={`h-full px-4 text-[10px] font-black uppercase border-b-2 transition-all ${view === 'images' ? 'text-blue-600 dark:text-blue-500 border-blue-600 dark:border-blue-500' : 'text-slate-400 dark:text-slate-500 border-transparent'}`}>Images</button>
        </div>
        <div className="flex flex-1 overflow-hidden relative">
          {renderView()}
          <ConsoleManager windows={consoleWindows} nodes={nodes} onCloseWindow={(id) => setConsoleWindows(prev => prev.filter(w => w.id !== id))} onCloseTab={(winId, nodeId) => setConsoleWindows(prev => prev.map(w => w.id === winId ? { ...w, deviceIds: w.deviceIds.filter(did => did !== nodeId) } : w).filter(w => w.deviceIds.length > 0))} onSetActiveTab={(winId, nodeId) => setConsoleWindows(prev => prev.map(w => w.id === winId ? { ...w, activeDeviceId: nodeId } : w))} onUpdateWindowPos={(id, x, y) => setConsoleWindows(prev => prev.map(w => w.id === id ? { ...w, x, y } : w))} />
        </div>
        <StatusBar />
        {showYamlModal && (
          <div className="fixed inset-0 z-[60] flex items-center justify-center bg-black/80 backdrop-blur-md">
            <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700 rounded-2xl w-[700px] max-h-[85vh] flex flex-col overflow-hidden shadow-2xl">
              <div className="p-5 border-b border-slate-100 dark:border-slate-800 flex justify-between items-center">
                <h3 className="text-slate-900 dark:text-slate-100 font-bold text-sm uppercase">YAML Preview</h3>
                <button onClick={() => setShowYamlModal(false)} className="text-slate-500 hover:text-slate-900 dark:hover:text-white"><i className="fa-solid fa-times"></i></button>
              </div>
              <div className="flex-1 p-6 overflow-y-auto bg-slate-50 dark:bg-slate-950/50 font-mono text-[11px] text-blue-700 dark:text-blue-300 whitespace-pre">{yamlContent}</div>
              <div className="p-5 border-t border-slate-100 dark:border-slate-800 flex justify-end gap-3">
                <button onClick={() => setShowYamlModal(false)} className="px-6 py-2 bg-blue-600 text-white font-black rounded-lg">DONE</button>
              </div>
            </div>
          </div>
        )}
      </div>
    </ThemeContext.Provider>
  );
};

export default App;
