
import React, { useState, useEffect } from 'react';
import { ConsoleWindow, Node } from '../types';

interface ConsoleManagerProps {
  windows: ConsoleWindow[];
  nodes: Node[];
  onCloseWindow: (windowId: string) => void;
  onCloseTab: (windowId: string, nodeId: string) => void;
  onSetActiveTab: (windowId: string, nodeId: string) => void;
  onUpdateWindowPos: (windowId: string, x: number, y: number) => void;
  onUpdateWindowSize?: (windowId: string, width: number, height: number) => void;
}

const ConsoleManager: React.FC<ConsoleManagerProps> = ({ 
  windows, nodes, onCloseWindow, onCloseTab, onSetActiveTab, onUpdateWindowPos 
}) => {
  const [dragState, setDragState] = useState<{ id: string, startX: number, startY: number } | null>(null);
  const [resizeState, setResizeState] = useState<{ id: string, startWidth: number, startHeight: number, startX: number, startY: number } | null>(null);
  const [winSizes, setWinSizes] = useState<Record<string, { w: number, h: number }>>({});

  const handleMouseDown = (e: React.MouseEvent, win: ConsoleWindow) => {
    // Only drag from the header area
    setDragState({ id: win.id, startX: e.clientX - win.x, startY: e.clientY - win.y });
  };

  const handleResizeMouseDown = (e: React.MouseEvent, win: ConsoleWindow) => {
    e.stopPropagation();
    e.preventDefault();
    const currentW = winSizes[win.id]?.w || 500;
    const currentH = winSizes[win.id]?.h || 350;
    setResizeState({ 
      id: win.id, 
      startWidth: currentW, 
      startHeight: currentH, 
      startX: e.clientX, 
      startY: e.clientY 
    });
  };

  useEffect(() => {
    const handleMouseMove = (e: MouseEvent) => {
      if (dragState) {
        onUpdateWindowPos(dragState.id, e.clientX - dragState.startX, e.clientY - dragState.startY);
      }
      if (resizeState) {
        const deltaX = e.clientX - resizeState.startX;
        const deltaY = e.clientY - resizeState.startY;
        setWinSizes(prev => ({
          ...prev,
          [resizeState.id]: {
            w: Math.max(300, resizeState.startWidth + deltaX),
            h: Math.max(200, resizeState.startHeight + deltaY)
          }
        }));
      }
    };

    const handleMouseUp = () => {
      setDragState(null);
      setResizeState(null);
    };

    if (dragState || resizeState) {
      window.addEventListener('mousemove', handleMouseMove);
      window.addEventListener('mouseup', handleMouseUp);
    }
    return () => {
      window.removeEventListener('mousemove', handleMouseMove);
      window.removeEventListener('mouseup', handleMouseUp);
    };
  }, [dragState, resizeState, onUpdateWindowPos]);

  return (
    <>
      {windows.map(win => {
        const size = winSizes[win.id] || { w: 500, h: 350 };
        const activeNode = nodes.find(n => n.id === win.activeDeviceId);

        return (
          <div 
            key={win.id}
            className="fixed z-40 bg-slate-900 border border-slate-700 rounded-lg shadow-2xl flex flex-col overflow-hidden ring-1 ring-white/5"
            style={{ 
              left: win.x, 
              top: win.y, 
              width: size.w, 
              height: size.h,
              boxShadow: dragState?.id === win.id || resizeState?.id === win.id ? '0 25px 50px -12px rgba(0, 0, 0, 0.7)' : '0 20px 25px -5px rgba(0, 0, 0, 0.4)'
            }}
          >
            {/* Header / Tabs */}
            <div 
              className="h-9 bg-slate-800 border-b border-slate-700 flex items-center cursor-move select-none shrink-0"
              onMouseDown={(e) => handleMouseDown(e, win)}
            >
              <div className="flex-1 flex items-center h-full overflow-x-auto no-scrollbar scroll-smooth">
                {win.deviceIds.map(nodeId => {
                  const node = nodes.find(n => n.id === nodeId);
                  const isActive = win.activeDeviceId === nodeId;
                  return (
                    <div 
                      key={nodeId}
                      onClick={(e) => { e.stopPropagation(); onSetActiveTab(win.id, nodeId); }}
                      className={`h-full px-4 flex items-center gap-2 text-[10px] font-bold border-r border-slate-700/50 transition-all cursor-pointer shrink-0 relative
                        ${isActive ? 'bg-slate-900 text-blue-400' : 'text-slate-500 hover:bg-slate-700/50 hover:text-slate-300'}`}
                    >
                      {isActive && <div className="absolute top-0 left-0 right-0 h-0.5 bg-blue-500" />}
                      <i className={`fa-solid ${isActive ? 'fa-terminal' : 'fa-rectangle-list'} scale-90`}></i>
                      <span className="truncate max-w-[80px]">{node?.name || 'Unknown'}</span>
                      <button 
                        onMouseDown={(e) => e.stopPropagation()}
                        onClick={(e) => { e.stopPropagation(); onCloseTab(win.id, nodeId); }}
                        className="ml-1 hover:text-red-400 p-0.5 transition-colors opacity-60 hover:opacity-100"
                      >
                        <i className="fa-solid fa-xmark"></i>
                      </button>
                    </div>
                  );
                })}
              </div>
              <div className="flex items-center px-2 gap-1.5 shrink-0 bg-slate-800 ml-auto border-l border-slate-700">
                 <button className="w-6 h-6 flex items-center justify-center text-slate-500 hover:text-slate-300 hover:bg-slate-700 rounded transition-all">
                  <i className="fa-solid fa-up-right-from-square text-[9px]"></i>
                 </button>
                 <button onClick={() => onCloseWindow(win.id)} className="w-6 h-6 flex items-center justify-center text-slate-500 hover:text-red-400 hover:bg-red-400/10 rounded transition-all">
                  <i className="fa-solid fa-xmark"></i>
                 </button>
              </div>
            </div>

            {/* Terminal Body */}
            <div className="flex-1 bg-black p-4 font-mono text-xs text-blue-400 overflow-y-auto leading-relaxed select-text relative group">
              <div className="text-slate-600 mb-2 border-b border-slate-800 pb-1 flex justify-between">
                <span>SESSION: {activeNode?.name || 'IDLE'}</span>
                <span className="text-[9px] opacity-50">CONNECTED via VTY</span>
              </div>
              
              {activeNode ? (
                <>
                  <div className="text-slate-500 italic mb-4">Aura Visual Studio Console Manager v1.2</div>
                  <div className="flex items-center gap-2">
                    <span className="text-green-500">{activeNode.name}</span>
                    <span className="text-slate-400">#</span>
                    <span className="text-slate-100">show running-config</span>
                  </div>
                  <div className="mt-2 text-slate-400 whitespace-pre">
                    Building configuration...<br/>
                    Current configuration : 1542 bytes<br/>
                    !<br/>
                    version 15.6<br/>
                    service timestamps debug datetime msec<br/>
                    service timestamps log datetime msec<br/>
                    no service password-encryption<br/>
                    !<br/>
                    hostname {activeNode.name}<br/>
                    !<br/>
                    boot-start-marker<br/>
                    boot-end-marker<br/>
                    ...
                  </div>
                  <div className="mt-6 flex gap-1">
                     <span className="text-green-500">{activeNode.name}#</span>
                     <span className="animate-pulse text-blue-500">█</span>
                     <input className="bg-transparent outline-none flex-1 text-slate-100" autoFocus />
                  </div>
                </>
              ) : (
                <div className="h-full flex flex-col items-center justify-center text-slate-700">
                  <i className="fa-solid fa-terminal text-4xl mb-4 opacity-10"></i>
                  <p className="text-xs font-bold uppercase tracking-widest opacity-30">No active session selected</p>
                </div>
              )}

              {/* Console Overlay for Copy etc */}
              <div className="absolute top-2 right-4 opacity-0 group-hover:opacity-100 transition-opacity">
                <button className="bg-slate-800 text-slate-400 px-2 py-1 rounded text-[9px] font-bold border border-slate-700 hover:bg-slate-700">COPY BUFFER</button>
              </div>
            </div>

            {/* Resize Handle */}
            <div 
              className="absolute bottom-0 right-0 w-5 h-5 cursor-nwse-resize flex items-end justify-end p-0.5 group pointer-events-auto"
              onMouseDown={(e) => handleResizeMouseDown(e, win)}
            >
              <div className="w-2 h-2 border-r-2 border-b-2 border-slate-700 group-hover:border-blue-500 transition-colors"></div>
            </div>
          </div>
        );
      })}
    </>
  );
};

export default ConsoleManager;
