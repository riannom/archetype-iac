
import React, { useState } from 'react';
import { DEVICE_CATEGORIES } from '../constants';
import { DeviceModel, DeviceImage, DeviceType } from '../types';

const DeviceManager: React.FC = () => {
  const [selectedDevice, setSelectedDevice] = useState<DeviceModel | null>(null);
  
  // Mock image data - in a real app this would come from a backend/localstorage
  const [deviceImages, setDeviceImages] = useState<Record<string, DeviceImage[]>>({
    'iosv': [
      { id: 'img-1', version: '15.9(3)M4', filename: 'vios-adventerprisek9-m.vmdk.SPA.159-3.M4', filesize: '154MB', isActive: true, uploadDate: '2023-10-12' },
      { id: 'img-2', version: '15.8', filename: 'vios-adventerprisek9-m.vmdk.SPA.158.bin', filesize: '142MB', isActive: false, uploadDate: '2023-08-05' }
    ],
    'eos': [
      { id: 'img-3', version: '4.28.0F', filename: 'vEOS-lab-4.28.0F.vmdk', filesize: '2.1GB', isActive: true, uploadDate: '2023-11-20' }
    ]
  });

  const toggleImage = (deviceId: string, imageId: string) => {
    setDeviceImages(prev => ({
      ...prev,
      [deviceId]: prev[deviceId].map(img => 
        img.id === imageId ? { ...img, isActive: !img.isActive } : img
      )
    }));
  };

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (!selectedDevice || !e.target.files?.[0]) return;
    const file = e.target.files[0];
    
    const newImage: DeviceImage = {
      id: Math.random().toString(36).substr(2, 9),
      version: 'New Version',
      filename: file.name,
      filesize: `${(file.size / (1024 * 1024)).toFixed(1)}MB`,
      isActive: true,
      uploadDate: new Date().toISOString().split('T')[0]
    };

    setDeviceImages(prev => ({
      ...prev,
      [selectedDevice.id]: [...(prev[selectedDevice.id] || []), newImage]
    }));
  };

  const allModels = DEVICE_CATEGORIES.flatMap(cat => cat.subCategories ? cat.subCategories.flatMap(s => s.models) : (cat.models || []));

  return (
    <div className="flex-1 bg-slate-950 flex flex-col overflow-hidden animate-in fade-in duration-300">
      <div className="p-8 max-w-7xl mx-auto w-full flex-1 flex flex-col overflow-hidden">
        <header className="mb-8 flex justify-between items-end">
          <div>
            <h1 className="text-3xl font-black text-white tracking-tight">Image Management</h1>
            <p className="text-slate-400 text-sm mt-1">Catalog your virtual appliance images and toggle device availability.</p>
          </div>
          <div className="flex gap-3">
            <button className="px-4 py-2 bg-slate-800 hover:bg-slate-700 text-white rounded-lg border border-slate-700 text-xs font-bold transition-all">
              <i className="fa-solid fa-download mr-2"></i> Import Catalog
            </button>
          </div>
        </header>

        <div className="grid grid-cols-12 gap-8 flex-1 overflow-hidden">
          {/* Device List */}
          <div className="col-span-4 flex flex-col gap-4 overflow-y-auto pr-2 custom-scrollbar">
            {allModels.map(model => (
              <div 
                key={model.id}
                onClick={() => setSelectedDevice(model)}
                className={`p-4 rounded-xl border transition-all cursor-pointer group ${
                  selectedDevice?.id === model.id 
                  ? 'bg-blue-600/10 border-blue-500 shadow-lg shadow-blue-900/20' 
                  : 'bg-slate-900 border-slate-800 hover:border-slate-700'
                }`}
              >
                <div className="flex items-start justify-between">
                  <div className="flex items-center gap-4">
                    <div className={`w-12 h-12 rounded-lg flex items-center justify-center text-xl shadow-inner ${
                      selectedDevice?.id === model.id ? 'bg-blue-500 text-white' : 'bg-slate-800 text-slate-400 group-hover:text-blue-400 transition-colors'
                    }`}>
                      <i className={`fa-solid ${model.icon}`}></i>
                    </div>
                    <div>
                      <h3 className="font-bold text-white text-sm">{model.name}</h3>
                      <span className="text-[10px] uppercase font-bold text-slate-500 tracking-wider">{model.type}</span>
                    </div>
                  </div>
                  <div className="flex flex-col items-end">
                    <span className={`w-2 h-2 rounded-full mb-1 ${model.isActive ? 'bg-green-500 shadow-[0_0_8px_rgba(34,197,94,0.5)]' : 'bg-slate-700'}`}></span>
                    <span className="text-[10px] text-slate-500 font-mono">{(deviceImages[model.id] || []).length} Imgs</span>
                  </div>
                </div>
              </div>
            ))}
          </div>

          {/* Details & Image Upload */}
          <div className="col-span-8 bg-slate-900/50 border border-slate-800 rounded-2xl flex flex-col overflow-hidden">
            {selectedDevice ? (
              <>
                <div className="p-6 border-b border-slate-800 bg-slate-900/50 flex justify-between items-center">
                  <div className="flex items-center gap-4">
                    <div className="w-10 h-10 rounded bg-blue-500/20 flex items-center justify-center text-blue-400 border border-blue-500/30">
                       <i className={`fa-solid ${selectedDevice.icon}`}></i>
                    </div>
                    <div>
                      <h2 className="text-xl font-bold text-white">{selectedDevice.name}</h2>
                      <p className="text-xs text-slate-500">Node Definition: <span className="font-mono text-blue-400">{selectedDevice.id}.yaml</span></p>
                    </div>
                  </div>
                  <div className="flex gap-2">
                    <label className="cursor-pointer bg-blue-600 hover:bg-blue-500 text-white px-4 py-2 rounded-lg text-xs font-bold transition-all flex items-center gap-2">
                      <i className="fa-solid fa-cloud-arrow-up"></i>
                      Upload Image
                      <input type="file" className="hidden" onChange={handleFileUpload} />
                    </label>
                  </div>
                </div>

                <div className="flex-1 overflow-y-auto p-6 space-y-4">
                  <div className="text-[10px] font-bold text-slate-500 uppercase tracking-widest mb-2">Registered Images</div>
                  {deviceImages[selectedDevice.id]?.length > 0 ? (
                    <div className="space-y-3">
                      {deviceImages[selectedDevice.id].map(img => (
                        <div key={img.id} className="flex items-center justify-between p-4 bg-slate-900 border border-slate-800 rounded-xl hover:border-slate-700 transition-all">
                          <div className="flex items-center gap-4">
                             <div className="w-10 h-10 rounded bg-slate-800 flex items-center justify-center text-slate-500">
                               <i className="fa-solid fa-file-zipper text-lg"></i>
                             </div>
                             <div>
                               <div className="flex items-center gap-2">
                                 <span className="text-sm font-bold text-white">{img.version}</span>
                                 {img.isActive && <span className="px-1.5 py-0.5 bg-green-500/10 text-green-500 text-[9px] font-bold rounded border border-green-500/20 uppercase">Active</span>}
                               </div>
                               <div className="text-[11px] text-slate-500 font-mono mt-0.5">{img.filename} • {img.filesize}</div>
                             </div>
                          </div>
                          <div className="flex items-center gap-4">
                             <div className="text-right mr-4">
                               <div className="text-[10px] text-slate-600 uppercase font-bold">Uploaded</div>
                               <div className="text-[11px] text-slate-400">{img.uploadDate}</div>
                             </div>
                             <button 
                               onClick={() => toggleImage(selectedDevice.id, img.id)}
                               className={`w-10 h-6 rounded-full relative transition-colors ${img.isActive ? 'bg-blue-600' : 'bg-slate-700'}`}
                             >
                               <div className={`absolute top-1 w-4 h-4 rounded-full bg-white transition-all ${img.isActive ? 'right-1' : 'left-1'}`}></div>
                             </button>
                             <button className="text-slate-600 hover:text-red-500 transition-colors p-2">
                               <i className="fa-solid fa-trash-can"></i>
                             </button>
                          </div>
                        </div>
                      ))}
                    </div>
                  ) : (
                    <div className="flex flex-col items-center justify-center py-20 text-slate-600 border-2 border-dashed border-slate-800 rounded-2xl">
                       <i className="fa-solid fa-box-open text-4xl mb-4 opacity-20"></i>
                       <p className="text-sm font-medium">No images uploaded for this device yet.</p>
                       <p className="text-xs opacity-60">Upload a qcow2, vmdk or container image to begin.</p>
                    </div>
                  )}
                </div>
              </>
            ) : (
              <div className="flex-1 flex flex-col items-center justify-center text-slate-600">
                 <div className="w-24 h-24 rounded-full bg-slate-900 border border-slate-800 flex items-center justify-center mb-6 shadow-2xl">
                    <i className="fa-solid fa-microchip text-4xl opacity-20"></i>
                 </div>
                 <h3 className="text-lg font-bold text-slate-400">Select a device to manage</h3>
                 <p className="text-sm max-w-xs text-center mt-2">Pick a device from the left sidebar to view its registered virtual images and metadata.</p>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};

export default DeviceManager;
